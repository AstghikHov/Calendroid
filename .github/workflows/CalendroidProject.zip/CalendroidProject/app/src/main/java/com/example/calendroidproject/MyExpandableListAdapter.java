package com.example.calendroidproject;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;
import java.util.StringTokenizer;

import java.util.HashMap;
import java.util.List;


public class MyExpandableListAdapter extends BaseExpandableListAdapter {
    private HashMap<String, List<String>> mStringListHashMap;
    private String[] mListHeaderGroup;

    public MyExpandableListAdapter(HashMap<String, List<String>> stringListHashMap) {
        mStringListHashMap = stringListHashMap;
        mListHeaderGroup = mStringListHashMap.keySet().toArray(new String[0]);
    }




    @Override
    public int getGroupCount() {
        return mListHeaderGroup.length;
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return mStringListHashMap.get(mListHeaderGroup[groupPosition]).size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return mListHeaderGroup[groupPosition];
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return mStringListHashMap.get(mListHeaderGroup[groupPosition]).get(childPosition);
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return groupPosition*childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        if (convertView == null)
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.expandable_list_group, parent, false);

        TextView textView = convertView.findViewById(R.id.textView);

        textView.setText(String.valueOf(getGroup(groupPosition)));



        String forColorCoding = String.valueOf(getGroup(groupPosition));



        if (forColorCoding.equals("Red") )
            textView.setTextColor(Color.parseColor("#ff0000"));
        if (forColorCoding.equals("Green"))
            textView.setTextColor(Color.parseColor("#006600"));
        if (forColorCoding.equals("Orange"))
            textView.setTextColor(Color.parseColor("#ff6600"));
        if (forColorCoding.equals("Blue"))
            textView.setTextColor(Color.parseColor("#0033cc"));
        if (forColorCoding.equals("Pink") )
            textView.setTextColor(Color.parseColor("#ff1a75"));
        if (forColorCoding.equals("Purple"))
            textView.setTextColor(Color.parseColor("#9900cc"));



        return convertView;
    }


    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        if (convertView == null)
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.expandable_list_item, parent, false);

        TextView textView = convertView.findViewById(R.id.textView);
        textView.setText(String.valueOf(getChild(groupPosition, childPosition)));



    /*
        TextView t= convertView.findViewById(R.id.textView);


        String data= String.valueOf(getChild(groupPosition, childPosition));


        if(data.indexOf("Color:")!=-1) {

            if (data.indexOf("Red") != -1)
                t.setTextColor(Color.parseColor("#ff0000"));
            if (data.indexOf("Green") != -1)
                t.setTextColor(Color.parseColor("#006600"));
            if (data.indexOf("Orange") != -1)
                t.setTextColor(Color.parseColor("#ff6600"));
            if (data.indexOf("Blue") != -1)
                t.setTextColor(Color.parseColor("#0033cc"));
            if (data.indexOf("Pink") != -1)
                t.setTextColor(Color.parseColor("#ff1a75"));
            if (data.indexOf("Purple") != -1)
                t.setTextColor(Color.parseColor("#9900cc"));
        }

*/

        return convertView;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return false;
    }
}
